# Restaurante Rafa — Sitio web multipágina

Sitio corporativo mobile-first con menú del día dinámico y panel de administración
para el dueño, según el briefing del cliente.

---

## 1. Pila tecnológica propuesta (y por qué)

| Capa | Elección | Motivo |
|---|---|---|
| Frontend | **HTML + CSS + JS puro, multipágina** | Cuatro páginas de contenido no justifican un framework. Carga instantánea en móvil (el 90 % del tráfico de un bar), cero build, cero dependencias que mantener. |
| Hosting | **GitHub Pages** (o Netlify/Cloudflare Pages) | Gratis, HTTPS incluido, se despliega con un `git push`. |
| Base de datos del menú | **Supabase (plan gratuito)** | Una tabla de UNA fila. Lectura pública, escritura solo con la sesión del dueño (RLS). Incluye autenticación y actualizaciones en tiempo real sin escribir backend. |
| Formulario de contacto | **Formspree (plan gratuito)** | 50 envíos/mes gratis, sin servidor. |

**¿Por qué no Next.js o Vue + Firebase?** El briefing los sugiere como ejemplo, pero
para este proyecto añaden coste sin beneficio: Next.js necesita build/SSR (GitHub
Pages no ejecuta servidor), y Firebase mete SDK + configuración más pesada para
exactamente la misma funcionalidad. Con una sola tabla y un solo editor, la opción
estática + Supabase es más rápida, más barata (0 €/mes) y la puede mantener una
sola persona. Si el proyecto creciera (reservas online, varios locales), migrar a
Next.js + Supabase sería el paso natural — la base de datos ya estaría lista.

---

## 2. Estructura

```
restaurante-rafa/
├── index.html          Portada: CTA llamar, arroces finde, horario, avisos
├── menu-diario.html    Menú del día dinámico (la "minuta")
├── la-carta.html       Carta fija completa con precios
├── contacto.html       Formulario, mapa, teléfonos
├── admin.html          Panel privado del dueño (no enlazado desde la web)
├── css/estilo.css      Sistema de diseño (paleta Opción B del briefing)
├── js/config.js        ⚙️ AQUÍ se pegan las claves de Supabase/Formspree
├── js/comun.js         Navegación, renderizador de la minuta, toasts
├── js/menu-diario.js   Lectura del menú + tiempo real
├── js/admin.js         Sesión del dueño + publicar
└── assets/             Logo en SVG (vectorial) y PNG (oscuro/blanco)
```

**Modo demo:** mientras `js/config.js` esté sin rellenar, toda la web funciona con
el menú de ejemplo de la minuta original. Perfecto para enseñársela a Rafa antes
de conectar nada.

---

## 3. Probar en local

```bash
cd restaurante-rafa
python3 -m http.server 8080
# abrir http://localhost:8080
```

(Abrir el archivo con doble clic también funciona para ojear el diseño, pero usa
un servidor local para probar el panel.)

---

## 4. Conectar Supabase (≈10 minutos, una sola vez)

1. Crea un proyecto gratuito en <https://supabase.com>.
2. En **SQL Editor**, ejecuta esto tal cual:

```sql
-- Tabla del menú del día (una sola fila, id = 1)
create table public.menu_diario (
  id integer primary key,
  dia text not null,
  primeros jsonb not null default '[]',
  segundos jsonb not null default '[]',
  sugerencia text default '',
  actualizado timestamptz not null default now()
);

-- Fila inicial con el menú de ejemplo
insert into public.menu_diario (id, dia, primeros, segundos, sugerencia)
values (
  1,
  'LUNES',
  '["Cazuela de lentejas a la castellana","Boquerones en vinagre","Gazpacho andaluz","Ensalada capresse"]',
  '["Pierna asada en salsa de naranja y setas","Pollo al ast / al romero","Canelones gratinados con bechamel","Bacalao vizcaína"]',
  'HAY SORBETE ALMENDRAS'
);

-- Seguridad: cualquiera puede LEER, solo el dueño (autenticado) puede ESCRIBIR
alter table public.menu_diario enable row level security;

create policy "lectura publica"
  on public.menu_diario for select
  using (true);

create policy "escritura del dueño"
  on public.menu_diario for update
  to authenticated
  using (true) with check (true);

-- Activa las actualizaciones en tiempo real para esta tabla
alter publication supabase_realtime add table public.menu_diario;
```

3. En **Authentication → Users → Add user**, crea el usuario del dueño
   (por ejemplo `rafa@restauranterafa.es` + una contraseña fácil de teclear en
   el móvil pero no obvia). Marca *Auto confirm user*.
4. En **Project Settings → API**, copia la **URL** y la clave **anon public**, y
   pégalas en `js/config.js`.

> 🔐 La clave *anon* está pensada para ser pública: la protección real son las
> políticas RLS de arriba (nadie puede escribir sin la contraseña del dueño).
> Lo que **nunca** debe publicarse es la clave `service_role`.

### Rutina diaria del dueño

Abrir `tudominio.com/admin.html` desde el móvil → entrar (la sesión se recuerda)
→ el día de hoy ya viene marcado → escribir los platos → **Publicar menú del día**.
Listo: la web pública se actualiza al instante, incluso para quien ya la tenga abierta.

---

## 5. Formulario de contacto

1. Crea un formulario gratuito en <https://formspree.io> con el email donde Rafa
   quiera recibir los mensajes.
2. Copia el ID (lo que va después de `/f/`) en `FORMSPREE_ID` de `js/config.js`.

Mientras no esté configurado, el formulario indica amablemente al visitante que
llame al 971 43 10 58.

---

## 6. Publicar en GitHub Pages

```bash
git init && git add . && git commit -m "Web Restaurante Rafa v1"
git branch -M main
git remote add origin https://github.com/sSILENTPIPE/restaurante-rafa.git
git push -u origin main
```

Luego en el repo: **Settings → Pages → Source: main / root**. En un minuto estará
en `https://ssilentpipe.github.io/restaurante-rafa/`. Cuando haya dominio propio
(p. ej. `restauranterafa.es`), se añade en la misma pantalla.

---

## 7. Datos a confirmar con Rafa antes de publicar

- [ ] **Horario**: la web dice *L–S 05:30–17:30* (sacado de directorios online).
      Confirmarlo en persona; se cambia en los 4 HTML buscando `05:30`.
- [ ] Email para el formulario de contacto (Formspree).
- [ ] ¿Quiere WhatsApp además del teléfono fijo? Se añade en un minuto.
- [ ] 2–3 fotos reales (fachada, paella del viernes, un menú servido) darían mucha
      vida a la portada — el hueco está pensado para admitirlas.
- [ ] El texto del aviso destacado de la portada (editable en `index.html`,
      bloque `<!-- AVISOS DESTACADOS -->`).

## Notas de diseño

- Paleta **Opción B "Taberna Tradicional y Brasa"** del briefing, con la regla
  60-30-10 estricta: fondo cálido (creme quente), estructura en marrón café
  oscuro, ámbar dorado para botones y arroces del fin de semana, rojo vino
  para el sello de postres caseros.
- El logo original (`.ai`/`.pdf`) se ha convertido a **SVG con `currentColor`**:
  un único archivo sirve en tinta oscura (portada, minuta) y en blanco
  (cabecera y pie, vía `filter`), sin perder nitidez a ningún tamaño.
- La página del menú replica la **minuta física** del local: día en grande,
  primeros/segundos, cláusulas fijas en mayúsculas y la sugerencia "escrita a
  mano". El panel del dueño muestra exactamente la misma pieza como vista previa.
